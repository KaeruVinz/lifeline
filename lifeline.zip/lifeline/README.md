# Lifeline
- backend/  : Supabase SQL only (tables, triggers, views, RLS, storage)
- frontend/ : HTML, CSS and JavaScript only. Set your keys in frontend/js/config.js, then open frontend/index.html

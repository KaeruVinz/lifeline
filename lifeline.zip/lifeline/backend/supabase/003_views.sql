-- Views
create view blood_availability as
  select blood_type, count(*) as donors from profiles
  where role='donor' and donor_status='active' and verified group by blood_type;

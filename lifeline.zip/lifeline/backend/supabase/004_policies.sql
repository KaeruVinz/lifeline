-- Row level security
alter table profiles enable row level security;
alter table requests enable row level security;

create policy "read profiles" on profiles for select to authenticated using(true);
create policy "edit own profile" on profiles for update to authenticated
  using(id=auth.uid()) with check(id=auth.uid() and verified=(select verified from profiles where id=auth.uid()));

create policy "patient creates" on requests for insert to authenticated with check(patient_id=auth.uid());
create policy "see requests" on requests for select to authenticated using(
  patient_id=auth.uid() or donor_id=auth.uid() or
  (status='pending' and blood_type=(select blood_type from profiles where id=auth.uid())));
create policy "update requests" on requests for update to authenticated using(
  patient_id=auth.uid() or donor_id=auth.uid() or
  (status='pending' and blood_type=(select blood_type from profiles where id=auth.uid())));

-- Storage for ID and medical certificates
-- private bucket for ID / medical certificates
insert into storage.buckets(id,name,public) values('docs','docs',false);
create policy "own docs" on storage.objects for all to authenticated
  using(bucket_id='docs' and (storage.foldername(name))[1]=auth.uid()::text)
  with check(bucket_id='docs' and (storage.foldername(name))[1]=auth.uid()::text);

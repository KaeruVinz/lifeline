-- Functions and triggers
-- profile from signup metadata; patients verified once email is confirmed
create function handle_new_user() returns trigger language plpgsql security definer as $$
begin
  insert into profiles(id,role,full_name,address,phone,blood_type)
  values(new.id,new.raw_user_meta_data->>'role',new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'address',new.raw_user_meta_data->>'phone',new.raw_user_meta_data->>'blood_type');
  return new; end $$;
create trigger on_signup after insert on auth.users for each row execute function handle_new_user();

create function handle_email_confirmed() returns trigger language plpgsql security definer as $$
begin
  if new.email_confirmed_at is not null then
    update profiles set verified=true where id=new.id and role='patient'; end if;
  return new; end $$;
create trigger on_confirm after update of email_confirmed_at on auth.users for each row execute function handle_email_confirmed();

-- donors are verified by an admin after reviewing ID + medical certificate:
-- update profiles set verified=true where id='<donor uuid>';

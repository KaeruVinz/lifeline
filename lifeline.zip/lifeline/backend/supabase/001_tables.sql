-- Tables
create table profiles(
  id uuid primary key references auth.users on delete cascade,
  role text not null check(role in('patient','donor')),
  full_name text, address text, phone text, blood_type text,
  donor_status text default 'inactive' check(donor_status in('active','inactive')),
  donations int default 0, reliability int default 100,
  verified boolean default false, id_doc text, med_cert text,
  lat float8, lng float8, created_at timestamptz default now());

create table requests(
  id uuid primary key default gen_random_uuid(),
  patient_id uuid references profiles not null,
  donor_id uuid references profiles,
  blood_type text not null,
  urgency text not null check(urgency in('normal','urgent','emergency')),
  units int not null check(units>0),
  status text default 'pending' check(status in('pending','accepted','declined')),
  declined_by uuid[] default '{}',
  patient_lat float8, patient_lng float8, donor_lat float8, donor_lng float8,
  hospital text, created_at timestamptz default now());

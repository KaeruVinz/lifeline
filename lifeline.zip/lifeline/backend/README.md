# Lifeline backend (Supabase)
Run these in the Supabase SQL Editor, in order:
1. supabase/001_tables.sql
2. supabase/002_functions_triggers.sql
3. supabase/003_views.sql
4. supabase/004_policies.sql
5. supabase/005_storage.sql

Then in Authentication settings, turn on "Confirm email".
Verify a donor after reviewing their documents:
  update profiles set verified = true where id = '<donor uuid>';

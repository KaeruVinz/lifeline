/* ---------- MATCH: share location / nearest hospital ---------- */
async function matchView(id,hosp=[]){
  const{data:r}=await sb.from('requests').select('*,patient:profiles!requests_patient_id_fkey(full_name,phone),donor:profiles!requests_donor_id_fkey(full_name,phone)').eq('id',id).single();
  const isP=me.role==='patient',other=isP?r.donor:r.patient;
  shell(`<div class="card"><h2>Meeting point</h2><p>${isP?'Donor':'Patient'}: <b>${esc(other?.full_name)}</b> · <a href="tel:${esc(other?.phone)}">${esc(other?.phone)}</a></p>
  <p>Hospital: <b>${esc(r.hospital||'not chosen yet')}</b></p><div id="map"></div>
  <button onclick="shareLoc('${id}')">Share my location</button> <button class="ghost" onclick="findHosp('${id}')">Find nearest hospitals</button> <button class="ghost" onclick="matchView('${id}')">Refresh</button>
  <div class="msg" id="mm"></div>${hosp.map(h=>`<div class="row"><span>${esc(h.name)}</span><button onclick="pickHosp('${id}',this.dataset.n)" data-n="${esc(h.name)}">Choose</button></div>`).join('')}
  <label>Or type a hospital</label><input id="hn"><button class="ghost" onclick="pickHosp('${id}',$('#hn').value)">Save hospital</button></div>`);
  const pts=[];if(r.patient_lat)pts.push([r.patient_lat,r.patient_lng,'Patient']);if(r.donor_lat)pts.push([r.donor_lat,r.donor_lng,'Donor']);
  drawMap(pts,pts[0]?[pts[0][0],pts[0][1]]:null);
  window._r=r;}
async function shareLoc(id){const p=await here();if(!p)return $('#mm').textContent='Allow location access to share it.';
  await sb.from('requests').update(me.role==='patient'?{patient_lat:p[0],patient_lng:p[1]}:{donor_lat:p[0],donor_lng:p[1]}).eq('id',id);matchView(id);}
async function findHosp(id){
  const r=window._r,pts=[[r.patient_lat,r.patient_lng],[r.donor_lat,r.donor_lng]].filter(p=>p[0]);
  const c=pts.length?[pts.reduce((s,p)=>s+p[0],0)/pts.length,pts.reduce((s,p)=>s+p[1],0)/pts.length]:await here();
  if(!c)return $('#mm').textContent='Share a location first so we can search nearby.';
  try{const q=`[out:json];nid=node["amenity"="hospital"]["name"](around:8000,${c[0]},${c[1]});out 8;`.replace('nid=','');
    const j=await(await fetch('https://overpass-api.de/api/interpreter',{method:'POST',body:'data='+encodeURIComponent(q)})).json();
    matchView(id,j.elements.map(e=>e.tags));}catch(e){$('#mm').textContent='Could not load hospitals. Type one instead.';}}
async function pickHosp(id,name){if(name)await sb.from('requests').update({hospital:name}).eq('id',id);matchView(id);}


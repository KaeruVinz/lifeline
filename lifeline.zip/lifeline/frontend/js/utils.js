// Shared helpers: Supabase client, theme, maps, geolocation
const sb=supabase.createClient(SUPABASE_URL,SUPABASE_KEY);
const BT=['A+','A-','B+','B-','AB+','AB-','O+','O-'];
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';');
const opts=(a,sel)=>a.map(x=>`<option ${x===sel?'selected':''}>${x}</option>`).join('');
const strong=p=>/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).{8,}$/.test(p);
const pwHint='Use 8+ characters with upper and lower case letters, a number and a symbol.';
const badge=p=>p.verified?'<span class="tag ok">Verified profile</span>':'<span class="tag warn">Not verified yet</span>';
let me=null,map=null,authMode='login',authRole='patient';

function setTheme(t){document.documentElement.dataset.theme=t;try{localStorage.setItem('theme',t)}catch(e){}}
setTheme((()=>{try{return localStorage.getItem('theme')}catch(e){}})()||(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light'));
const dist=(a,b,c,d)=>{const r=x=>x*Math.PI/180,h=Math.sin(r(c-a)/2)**2+Math.cos(r(a))*Math.cos(r(c))*Math.sin(r(d-b)/2)**2;return 12742*Math.asin(Math.sqrt(h))};
const here=()=>new Promise(res=>navigator.geolocation?navigator.geolocation.getCurrentPosition(p=>res([p.coords.latitude,p.coords.longitude]),()=>res(null)):res(null));
function drawMap(pts,center){if(map)map.remove();map=L.map('map').setView(center||[0,0],center?12:2);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap'}).addTo(map);
  pts.forEach(p=>L.marker([p[0],p[1]]).addTo(map).bindPopup(p[2]));}


/* ---------- DONOR ---------- */
async function donorHome(){
  const{data}=await sb.from('requests').select('*,patient:profiles!requests_patient_id_fkey(full_name,phone,verified)').order('created_at',{ascending:false});
  const open=(data||[]).filter(r=>r.status==='pending'&&!r.declined_by.includes(me.id)),mine=(data||[]).filter(r=>r.donor_id===me.id);
  const on=me.donor_status==='active';
  shell(`<div class="card"><h2>${esc(me.full_name)} ${badge(me)}</h2><p>Blood type <b>${esc(me.blood_type)}</b> · <b>${me.donations}</b> donations · <b>${me.reliability}%</b> reliable</p>
  <button onclick="setStatus('${on?'inactive':'active'}')">${on?'Active. Tap to go inactive':'Inactive. Tap to go active'}</button>
  <button class="ghost" onclick="saveLoc()">Update my location</button><div class="msg" id="dm"></div></div>
  <div class="card"><h2>Requests for ${esc(me.blood_type)}</h2>${open.map(r=>`<div class="row"><div><b>${r.units} unit(s)</b> <span class="tag ${r.urgency==='normal'?'mute':'bad'}">${r.urgency}</span><br><span class="mute">${esc(r.patient?.full_name)}</span></div>
  <div><button onclick="answer('${r.id}',true)">Confirm</button> <button class="ghost" onclick="answer('${r.id}',false)">Decline</button></div></div>`).join('')||'<p class="mute">No open requests for your blood type.</p>'}</div>
  <div class="card"><h2>Accepted</h2>${mine.map(r=>`<div class="row"><span>${esc(r.patient?.full_name)} · ${r.units} unit(s)</span><button onclick="matchView('${r.id}')">Open</button></div>`).join('')||'<p class="mute">Nothing yet.</p>'}</div>`);}
async function setStatus(s){await sb.from('profiles').update({donor_status:s}).eq('id',me.id);me.donor_status=s;donorHome();}
async function saveLoc(){const p=await here();if(!p)return $('#dm').textContent='Allow location access to update it.';
  await sb.from('profiles').update({lat:p[0],lng:p[1]}).eq('id',me.id);$('#dm').textContent='Location saved.';}
async function answer(id,yes){
  if(yes){const{data}=await sb.from('requests').update({donor_id:me.id,status:'accepted'}).eq('id',id).eq('status','pending').select();
    return data?.length?matchView(id):donorHome();}
  const{data:r}=await sb.from('requests').select('declined_by').eq('id',id).single();
  await sb.from('requests').update({declined_by:[...r.declined_by,me.id]}).eq('id',id);donorHome();}


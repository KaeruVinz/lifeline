// Paste your Supabase project URL and anon (public) key. Access is protected by the RLS policies in /backend.
const SUPABASE_URL='YOUR_SUPABASE_URL', SUPABASE_KEY='YOUR_SUPABASE_ANON_KEY';

/* ---------- AUTH ---------- */
function authView(msg=''){
  const su=authMode==='signup',d=authRole==='donor';
  $('#app').innerHTML=`<main style="max-width:440px"><div class="brand" style="font-size:38px;margin:24px 0">Lifeline</div><div class="card">
  <div class="tabs"><button class="${su?'ghost':''}" onclick="authMode='login';authView()">Log in</button><button class="${su?'':'ghost'}" onclick="authMode='signup';authView()">Sign up</button></div>
  ${su?`<div class="tabs"><button class="${d?'ghost':''}" onclick="authRole='patient';authView()">I need blood</button><button class="${d?'':'ghost'}" onclick="authRole='donor';authView()">I want to donate</button></div>
  <label>Full name</label><input id="fn" autocomplete="name">
  <label>Address</label><input id="ad" autocomplete="street-address">
  <label>Phone number (used for calls and texts)</label><input id="ph" type="tel">
  ${d?`<label>Blood type</label><select id="bt">${opts(BT)}</select>`:''}`:''}
  <label>${d&&su?'Email (use a real Gmail or email account)':'Email'}</label><input id="em" type="email" autocomplete="email">
  <label>Password</label><input id="pw" type="password" autocomplete="${su?'new-password':'current-password'}">
  <div class="msg ${msg.startsWith('Check')?'ok':'bad'}" id="am">${esc(msg)}</div>
  <button onclick="${su?'signUp()':'logIn()'}" style="width:100%">${su?'Create account':'Log in'}</button></div></main>`;}
async function logIn(){const{error}=await sb.auth.signInWithPassword({email:$('#em').value,password:$('#pw').value});if(error)authView(error.message);}
async function signUp(){
  const v=id=>$(id)?.value.trim();
  if(!v('#fn')||!v('#ad')||!v('#ph'))return authView('Fill in your name, address and phone number.');
  if(!strong($('#pw').value))return authView(pwHint);
  const{error}=await sb.auth.signUp({email:v('#em'),password:$('#pw').value,options:{data:{role:authRole,full_name:v('#fn'),address:v('#ad'),phone:v('#ph'),blood_type:v('#bt')||null}}});
  authMode='login';authView(error?error.message:'Check your email and click the verification link, then log in.');}


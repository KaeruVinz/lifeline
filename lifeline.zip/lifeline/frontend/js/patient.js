/* ---------- PATIENT ---------- */
async function patientHome(bt=''){
  const[{data:av},{data:donors},{data:reqs}]=await Promise.all([
    sb.from('blood_availability').select('*'),
    sb.from('profiles').select('*').eq('role','donor'),
    sb.from('requests').select('*').eq('patient_id',me.id).order('created_at',{ascending:false})]);
  const pos=await here();
  let list=(donors||[]).filter(d=>!bt||d.blood_type===bt);
  if(pos)list.sort((a,b)=>(a.lat?dist(pos[0],pos[1],a.lat,a.lng):1e9)-(b.lat?dist(pos[0],pos[1],b.lat,b.lng):1e9));
  shell(`<div class="card"><h2>Blood available now</h2><div class="grid">${BT.map(t=>`<div class="bt"><b>${t}</b>${(av||[]).find(a=>a.blood_type===t)?.donors||0} donors</div>`).join('')}</div></div>
  <div class="card"><h2>Find a donor</h2><label>Blood type</label><select onchange="patientHome(this.value)"><option value="">All types</option>${opts(BT,bt)}</select>
  <div id="map"></div>${list.map(d=>`<div class="row"><div><b>${esc(d.full_name)}</b> ${badge(d)}<br><span class="mute">${esc(d.blood_type)} · ${d.donations} donations · ${d.reliability}% reliable${pos&&d.lat?` · ${dist(pos[0],pos[1],d.lat,d.lng).toFixed(1)} km`:''}</span></div>
  <span class="tag ${d.donor_status==='active'?'ok':'mute'}">${d.donor_status}</span></div>`).join('')||'<p class="mute">No donors for this blood type yet.</p>'}</div>
  <div class="card"><h2>Request blood</h2><label>Blood type needed</label><select id="rb">${opts(BT,bt)}</select>
  <label>How urgent?</label><select id="ru"><option>normal</option><option>urgent</option><option>emergency</option></select>
  <label>Units needed</label><input id="rn" type="number" min="1" value="1"><div class="msg" id="rm"></div><button onclick="sendRequest()">Send request</button></div>
  <div class="card"><h2>My requests</h2>${(reqs||[]).map(r=>`<div class="row"><span>${esc(r.blood_type)} · ${r.units} unit(s) · ${r.urgency}</span><span>${r.status==='accepted'?`<button onclick="matchView('${r.id}')">A donor accepted. Open</button>`:`<span class="tag warn">waiting</span>`}</span></div>`).join('')||'<p class="mute">You have not sent a request yet.</p>'}</div>`);
  drawMap(list.filter(d=>d.lat).map(d=>[d.lat,d.lng,`${esc(d.full_name)} (${esc(d.blood_type)}, ${d.donor_status})`]),pos||(list.find(d=>d.lat)?[list.find(d=>d.lat).lat,list.find(d=>d.lat).lng]:null));}
async function sendRequest(){
  const pos=await here(),{error}=await sb.from('requests').insert({patient_id:me.id,blood_type:$('#rb').value,urgency:$('#ru').value,units:+$('#rn').value,patient_lat:pos?.[0],patient_lng:pos?.[1]});
  if(error)$('#rm').textContent=error.message;else patientHome();}


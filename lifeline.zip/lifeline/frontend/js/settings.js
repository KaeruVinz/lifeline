/* ---------- SETTINGS ---------- */
function settings(msg=''){
  const t=document.documentElement.dataset.theme,d=me.role==='donor';
  shell(`<div class="card"><h2>Appearance</h2><button class="${t==='light'?'':'ghost'}" onclick="setTheme('light');settings()">Light</button> <button class="${t==='dark'?'':'ghost'}" onclick="setTheme('dark');settings()">Dark</button></div>
  <div class="card"><h2>Profile</h2><p><b>${esc(me.full_name)}</b> ${badge(me)}</p><p class="mute">${me.role==='patient'?'Patient profiles are verified once the email is confirmed.':'Donor profiles are verified after the ID and medical certificate are reviewed.'}</p>
  ${d?`<label>Government ID</label><input id="f1" type="file" accept="image/*,.pdf"><label>Latest medical certificate</label><input id="f2" type="file" accept="image/*,.pdf"><button onclick="upDocs()">Submit for verification</button>`:''}</div>
  <div class="card"><h2>Privacy and security</h2><div class="msg ${msg.includes('.')&&!msg.includes('use')?'ok':'bad'}">${esc(msg)}</div>
  <label>New password (optional)</label><input id="np" type="password" autocomplete="new-password"><button class="ghost" onclick="chg('pw')">Change password</button><br><br>
  <label>Email (optional)</label><input id="ne" type="email" placeholder="new@email.com"><button class="ghost" onclick="chg('em')">Change email</button><br><br>
  <label>Phone number (optional)</label><input id="nph" type="tel" value="${esc(me.phone)}"><button class="ghost" onclick="chg('ph')">Save phone</button></div>`);}
async function chg(k){let e;
  if(k==='pw'){if(!strong($('#np').value))return settings(pwHint);({error:e}=await sb.auth.updateUser({password:$('#np').value}));}
  if(k==='em'){if(!$('#ne').value)return;({error:e}=await sb.auth.updateUser({email:$('#ne').value}));}
  if(k==='ph'){({error:e}=await sb.from('profiles').update({phone:$('#nph').value}).eq('id',me.id));me.phone=$('#nph').value;}
  settings(e?e.message:'Saved. For a new email, confirm it from the link we sent.');}
async function upDocs(){const a=$('#f1').files[0],b=$('#f2').files[0];if(!a||!b)return settings('Choose both files to submit.');
  const up=async(f,n)=>{const p=`${me.id}/${n}-${Date.now()}`;const{error}=await sb.storage.from('docs').upload(p,f);if(error)throw error;return p};
  try{await sb.from('profiles').update({id_doc:await up(a,'id'),med_cert:await up(b,'cert')}).eq('id',me.id);settings('Submitted. We will review your documents.');}
  catch(e){settings(e.message);}}

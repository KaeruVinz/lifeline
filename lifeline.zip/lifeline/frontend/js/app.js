// App entry: session check, page shell, routing. Load this file last.
sb.auth.onAuthStateChange(()=>boot());
async function boot(){
  const{data:{session}}=await sb.auth.getSession();
  if(!session)return authView();
  const{data}=await sb.from('profiles').select('*').eq('id',session.user.id).single();
  me=data;me.email_ok=!!session.user.email_confirmed_at;home();}


/* ---------- SHELL ---------- */
function shell(inner){
  $('#app').innerHTML=`<header><span class="brand">Lifeline</span><button class="ghost" onclick="home()">Home</button><button class="ghost" onclick="settings()">Settings</button><button class="ghost" onclick="sb.auth.signOut()">Log out</button></header><main>${inner}</main>`;}
const home=()=>me.role==='donor'?donorHome():patientHome();


boot();
